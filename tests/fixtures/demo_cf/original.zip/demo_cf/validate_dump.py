#!/usr/bin/env python3
"""Static checks of this demo dump. No 1C runtime or third-party packages required."""
from pathlib import Path
from collections import Counter
import re
import uuid
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
MD = 'http://v8.1c.ru/8.3/MDClasses'
LF = 'http://v8.1c.ru/8.3/xcf/logform'
V8 = 'http://v8.1c.ru/8.1/data/core'
XR = 'http://v8.1c.ru/8.3/xcf/readable'
NS = {'m': MD, 'f': LF, 'v8': V8, 'xr': XR}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def named_attributes(parent):
    return {n.findtext('m:Properties/m:Name', namespaces=NS): n
            for n in parent.findall('m:ChildObjects/m:Attribute', NS)}


def main():
    xmls = {p: ET.parse(p).getroot() for p in sorted(ROOT.rglob('*.xml'))}
    require(len(xmls) == 15, 'Expected 15 XML files')
    metadata = {}
    all_ids = []
    for path, root in xmls.items():
        if root.tag.endswith('ClientApplicationInterface'):
            continue
        require(root.get('version') == '2.8', f'{path}: inconsistent XML format version')
        if root.tag == f'{{{MD}}}MetaDataObject':
            obj = root[0]
            name = obj.findtext('m:Properties/m:Name', namespaces=NS)
            kind = obj.tag.split('}')[1]
            if kind == 'Form':
                name = f'Catalog.{path.parent.parent.name}.Form.{name}'
            else:
                name = f'{kind}.{name}'
            metadata[name] = obj
            for node in obj.iter():
                identifier = node.get('uuid')
                if identifier:
                    uuid.UUID(identifier)
                    all_ids.append(identifier)
                if node.tag in (f'{{{XR}}}TypeId', f'{{{XR}}}ValueId', f'{{{XR}}}ObjectId'):
                    uuid.UUID(node.text)
                    all_ids.append(node.text)
    require(len(all_ids) == len(set(all_ids)), 'Duplicate metadata/type UUID')
    conf = metadata['Configuration.ДемоНоменклатура']
    require(conf.findtext('m:Properties/m:DefaultLanguage', namespaces=NS) == 'Language.Русский', 'Default language')
    for child in conf.find('m:ChildObjects', NS):
        require(child.tag.split('}')[1] + '.' + child.text in metadata, f'Missing root object {child.text}')

    catalogs = {name.split('.', 1)[1]: obj for name, obj in metadata.items()
                if name.startswith('Catalog.') and '.Form.' not in name}
    require(set(catalogs) == {'ВидыНоменклатуры', 'Склады', 'Номенклатура'}, 'Unexpected catalogs')
    expected_forms = {'ВидыНоменклатуры': {'ФормаЭлемента'}, 'Склады': set(),
                      'Номенклатура': {'ФормаЭлемента', 'ФормаСписка'}}
    for name, obj in catalogs.items():
        require(obj.findtext('m:Properties/m:Hierarchical', namespaces=NS) == 'false', f'{name}: hierarchy')
        forms = {n.text for n in obj.findall('m:ChildObjects/m:Form', NS)}
        require(forms == expected_forms[name], f'{name}: unexpected custom forms')
        for form in forms:
            require(f'Catalog.{name}.Form.{form}' in metadata, f'{name}: missing form descriptor')
        for prop in obj.find('m:Properties', NS):
            if prop.tag.split('}')[1].endswith('Form') and prop.text:
                require(prop.text in metadata, f'{name}: invalid default form {prop.text}')
        require(obj.findtext('m:Properties/m:Autonumbering', namespaces=NS) == 'true', f'{name}: autonumbering')

    n = catalogs['Номенклатура']
    attrs = named_attributes(n)
    require(set(attrs) == {'ВидНоменклатуры'}, 'Nomenclature attributes')
    require(attrs['ВидНоменклатуры'].findtext('m:Properties/m:Type/v8:Type', namespaces=NS)
            == 'cfg:CatalogRef.ВидыНоменклатуры', 'Nomenclature kind type')
    tables = n.findall('m:ChildObjects/m:TabularSection', NS)
    require(len(tables) == 1 and tables[0].findtext('m:Properties/m:Name', namespaces=NS) == 'Склады', 'Warehouse section')
    columns = named_attributes(tables[0])
    require(set(columns) == {'Склад'}, 'Warehouse columns')
    require(columns['Склад'].findtext('m:Properties/m:Type/v8:Type', namespaces=NS)
            == 'cfg:CatalogRef.Склады', 'Warehouse reference type')

    subsystem = metadata['Subsystem.НормативнаяИнформация']
    require({n.text for n in subsystem.findall('m:Properties/m:Content/xr:Item', NS)}
            == {f'Catalog.{name}' for name in catalogs}, 'Subsystem content')
    for path, root in xmls.items():
        if root.tag != f'{{{LF}}}Form':
            continue
        catalog_name = path.parents[3].name
        ids = [n.get('id') for n in root.findall('f:ChildItems//*', NS) if n.get('id')]
        require(len(ids) == len(set(ids)), f'{path}: repeated UI IDs')
        names = [n.get('name') for n in root.findall('f:ChildItems//*', NS) if n.get('id') and n.get('name')]
        require(len(names) == len(set(names)), f'{path}: repeated UI names')
        require(len(root.findall('f:Attributes/f:Attribute[f:MainAttribute="true"]', NS)) == 1, f'{path}: main attribute')
        module_path = path.parent / 'Form' / 'Module.bsl'
        code = module_path.read_text(encoding='utf-8')
        procedures = set(re.findall(r'(?im)^Процедура\s+(\w+)\s*\(', code))
        for event in root.findall('.//f:Event', NS):
            require(event.text in procedures, f'{path}: missing event procedure {event.text}')
        commands = {n.get('name'): n for n in root.findall('f:Commands/f:Command', NS)}
        for name, command in commands.items():
            require(command.findtext('f:Action', namespaces=NS) in procedures, f'{path}: missing command handler {name}')
        for node in root.findall('.//f:CommandName', NS):
            require(node.text.removeprefix('Form.Command.') in commands, f'{path}: dangling button command')
        allowed_paths = {'Объект.Code', 'Объект.Description'}
        if catalog_name == 'Номенклатура':
            allowed_paths |= {'Объект.ВидНоменклатуры', 'Объект.Склады', 'Объект.Склады.Склад',
                              'Список', 'Список.Code', 'Список.Description', 'Список.ВидНоменклатуры'}
        for node in root.findall('.//f:DataPath', NS):
            require(node.text in allowed_paths, f'{path}: unknown binding {node.text}')
        for node in root.findall('.//v8:Type', NS):
            if node.text.startswith('cfg:CatalogObject.'):
                require(node.text == f'cfg:CatalogObject.{catalog_name}', f'{path}: incorrect object type')

    modules = list(ROOT.rglob('*.bsl'))
    require(len(modules) == 4, 'Expected one object module and three form modules')
    for path in modules:
        code = path.read_text(encoding='utf-8')
        # Lexical sanity check only: this is not a BSL compiler.
        stripped = re.sub(r'"(?:""|[^"\n])*"', '""', code)
        stripped = re.sub(r'//[^\n]*', '', stripped)
        tokens = Counter(re.findall(r'\b(?:Процедура|КонецПроцедуры|Если|КонецЕсли|Цикл|КонецЦикла)\b', stripped))
        for start, end in [('Процедура', 'КонецПроцедуры'), ('Если', 'КонецЕсли'), ('Цикл', 'КонецЦикла')]:
            require(tokens[start] == tokens[end], f'{path}: unbalanced {start}/{end}')
        require(stripped.count('(') == stripped.count(')'), f'{path}: parentheses')
    print(f'OK: {len(xmls)} XML, {len(catalogs)} catalogs, 3 custom forms, {len(modules)} BSL modules.')
    print('Checked metadata references, UUIDs, form bindings and handlers, BSL block balance.')
    print('1C import, BSL compilation and runtime behavior were not checked.')


if __name__ == '__main__':
    main()
